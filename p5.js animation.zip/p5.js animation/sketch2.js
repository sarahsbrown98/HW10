// JavaScript source code
var x = 250
var y = 150
var a = 50
var b = 10
var c = 300
var d = 10
var e = 65
var f = 10
var g = 150
var i = 151
var textsize = 32
var textgrow = 1

var movement = Math.floor(Math.random() * 10);


// JavaScript source code
function setup() {
    createCanvas(500, 500);
}

function draw() {
    background(165, 207, 250);

    //face
    noStroke()
    fill(247, 221, 212);
    ellipse(200, 200, 300, 380);

    //hair
    noStroke()
    fill(32, 19, 19);
    rect(a, b, 50, 400);
    rect(e, f, 270, 50);
    rect(c, d, 50, 400);
    if (a >= 500 || b <= 0) {
        movement *= -1;
    }

    a += movement;

    if (c >= 500 || b <= 0) {
        movement *= -1;
    }
    d += movement;

    if (e >= 500 || f <= 0) {
        movement *= 1;
    }
    f += movement;

    //eyes
    ellipse(x, y, 30, 35);
    ellipse(g, i, 30, 35);
    if (x >= 500 || x <= 0) {
        movement *= -1;
    }

    x = x + movement;

    if (g >= 500 || i <= 0) {
        movement *= -1
    }
    g += movement;
    i += movement;



    //Nose
    //strokeWeight(2)
    stroke('black')
    strokeWeight(1)
    fill(255, 237, 156);
    triangle(165, 250, 208, 200, 230, 250);


    //Mouth
    noStroke()
    fill(255, 102, 102);
    arc(200, 300, 80, 50, 0, PI);

    //eyebrow
    stroke('black')
    strokeWeight(3)
    line(235, 110, 270, 110);
    line(130, 110, 165, 110);

    //eye points
    stroke('white');
    strokeWeight(3)
    point(250, 150);
    point(150, 150);

    //Title
    textSize(textsize);
    text('Sarah Shapes', 100, 40);
    if (textsize >= 160 || textsize <= 0) { textgrow *= -1; }
    textsize += textgrow;

    //signature
    textSize(32)
    text('Sarah Brown', 300, 470)






}